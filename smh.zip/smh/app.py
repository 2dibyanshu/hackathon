from flask import Flask, render_template, request
import pickle
import numpy as np
import sklearn
import nltk
app = Flask(__name__)

# Load the model outside the route function to avoid loading it on every request
model = pickle.load(open('RFmodel1.pkl', 'rb'))

# Function to remove special characters
def rempunc(a):
    puncs = "!”#$%&'()*+,-./:;?@[\]^_`{|}~"
    newstr = ""
    for i in a:
        if i not in puncs:
            newstr += i
    return newstr

# Function for tokenization
def tokenize(a):
    lst = a.split()
    return lst

# Load stopwords
nltk.download('stopwords')
garbagewords = set(nltk.corpus.stopwords.words('english'))

# Function to remove stopwords
def removegw(l):
    lst = list(set(l) - garbagewords)
    return lst

@app.route('/')
def index():
    # Add any relevant code for the index route, if needed
    return render_template('index.html')  # You need to return a response here

@app.route('/predict', methods=['POST'])
def predict():
    # Access the global model variable
    global model

    # Get the input sentence from the request form
    input_sentence = request.form['input_values']

    # Ensure exactly 1 sentence is provided
    if not input_sentence:
        return render_template('index.html')

    # Remove special characters
    cleaned_sentence = rempunc(input_sentence)

    # Tokenize the cleaned sentence
    tokenized_sentence = tokenize(cleaned_sentence)

    # Remove stopwords
    filtered_tokens = removegw(tokenized_sentence)

    # Convert the sentence to a numpy array and make a prediction
    input_array = np.array([' '.join(filtered_tokens)])
    prediction = model.predict(input_array)

    # Pass the prediction to the template
    return render_template('index.html', prediction_text=f'The predicted class is {prediction}')

if __name__ == '__main__':
    app.run(debug=True)
