from flask import Flask, request, render_template
import numpy as np
pipimport pickle5 as pickle
app=Flask(__name__)
model = pickle.load(open("NBmodel.pkl", 'rb'))
@app.route('/')
def home():
    return render_template('page.html')
@app.route('/predict',methods=['POST'])
def predict():
    features=[request.form.values()]
    prediction=model.predict(features)
    output=prediction
    return render_template('page.html',prediction_text='The preditcion is {}'.format(output))

if __name__=='__main__':
    app.run(debug=True)
